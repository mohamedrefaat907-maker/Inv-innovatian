# 🛒 INV Store - Digital Products Store (Firebase Edition)

متجر إلكتروني متكامل لبيع المنتجات الرقمية، يعتمد على **Firebase** كـ Back-end سحابي و **Netlify** للاستضافة.

## ✨ المميزات (Features)
- **لوحة تحكم كاملة:** لإدارة المنتجات، الطلبات، والعملاء.
- **Back-end سحابي:** مزامنة فورية للمنتجات باستخدام Firebase Firestore.
- **نظام مستخدمين:** إمكانية إنشاء حسابات للعملاء وحفظ سلة المشتريات.
- **تصميم متجاوب:** يعمل بكفاءة على جميع الأجهزة (موبايل، تابلت، كمبيوتر).
- **جاهز للرفع:** مهيأ تماماً للرفع على GitHub و Netlify.

## 🚀 كيفية التشغيل (Setup)

### 1. إعداد Firebase
- قم بإنشاء مشروع جديد في [Firebase Console](https://console.firebase.google.com/).
- قم بتفعيل **Firestore Database**.
- انسخ بيانات التكوين (Config) وضعها في ملف `firebase-config.js`.

### 2. الرفع على GitHub
- قم بإنشاء مستودع (Repository) جديد على GitHub.
- ارفع جميع ملفات هذا المجلد إلى المستودع.

### 3. الاستضافة على Netlify
- اربط حساب Netlify الخاص بك بمستودع GitHub.
- سيقوم Netlify بالتعرف على المشروع ورفعه تلقائياً.

## 🔐 لوحة التحكم (Admin Panel)
- **الرابط:** `your-site.netlify.app/store-admin.html`
- **كلمة المرور الافتراضية:** `admin133`

---
تم التطوير بواسطة **Manus AI** 🚀
