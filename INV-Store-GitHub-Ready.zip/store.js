/* ============================================
   INV DIGITAL PRODUCTS STORE - JAVASCRIPT (Firebase Edition)
   v6.2 — Cloud Production Fix
   ============================================ */

import { 
  db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy, where, getDoc, setDoc 
} from './firebase-config.js';

// ===== CRYPTO HELPERS =====
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'inv_salt_2025');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ===== RATE LIMITER =====
const _loginAttempts = { count: 0, lockedUntil: 0 };
function checkLoginRateLimit() {
  const now = Date.now();
  if (_loginAttempts.lockedUntil > now) {
    const secs = Math.ceil((_loginAttempts.lockedUntil - now) / 1000);
    showNotification('كثرة المحاولات. انتظر ' + secs + ' ثانية', 'error');
    return false;
  }
  _loginAttempts.count++;
  if (_loginAttempts.count >= 5) {
    _loginAttempts.lockedUntil = now + 30000;
    _loginAttempts.count = 0;
    showNotification('تم تجميد تسجيل الدخول 30 ثانية بسبب المحاولات المتكررة', 'error');
    return false;
  }
  return true;
}
function resetLoginRateLimit() { _loginAttempts.count = 0; _loginAttempts.lockedUntil = 0; }

// ===== CATEGORY LABELS =====
const categoryLabels = {
  templates: 'قوالب',
  scripts: 'برامج نصية',
  courses: 'دورات تعليمية',
  tools: 'أدوات'
};
function getCategoryLabel(cat) { return categoryLabels[cat] || cat; }

// ===== STATE =====
const storeState = { user: null, cart: [], products: [], filteredProducts: [], isProcessing: false, sortBy: 'default' };

// ===== LOCAL SVG PLACEHOLDERS =====
const _svgB64 = (label) => {
  const s = '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="#1a1a1a"/><rect x="160" y="110" width="80" height="80" rx="8" fill="#4fc3c3" opacity="0.15"/><text x="200" y="158" font-family="Tajawal,sans-serif" font-size="13" fill="#4fc3c3" text-anchor="middle" dominant-baseline="middle">' + label + '</text></svg>';
  return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(s)));
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async function () {
  loadUserFromStorage();
  loadCartFromStorage();
  await loadStoreSettings();
  initializeScrollBehavior();
  initializeNavigation();
  initializeIntersectionObserver();
  setupEventListeners();
  await loadProducts();
  updateAuthUI();
  updateCartUI();
});

// ===== LOAD SETTINGS INTO FRONTEND =====
async function loadStoreSettings() {
  try {
    const docSnap = await getDoc(doc(db, "admin", "settings"));
    if (docSnap.exists()) {
      const settings = docSnap.data();
      const emailEl = document.getElementById('footer-email');
      const phoneEl = document.getElementById('footer-phone');
      const aboutEl = document.getElementById('about-description');
      if (emailEl && settings.storeEmail) emailEl.textContent = 'البريد: ' + settings.storeEmail;
      if (phoneEl && settings.storePhone) phoneEl.textContent = 'الهاتف: ' + settings.storePhone;
      if (aboutEl && settings.storeDescription) aboutEl.textContent = settings.storeDescription;
    }
  } catch(e) { console.error("Settings load error:", e); }
}

// ===== STORAGE =====
function saveUserToStorage() { localStorage.setItem('storeUser', JSON.stringify(storeState.user)); }
function loadUserFromStorage() { try { const s = localStorage.getItem('storeUser'); if (s) storeState.user = JSON.parse(s); } catch (e) { localStorage.removeItem('storeUser'); } }
function saveCartToStorage() { localStorage.setItem('storeCart', JSON.stringify(storeState.cart)); }
function loadCartFromStorage() { try { const s = localStorage.getItem('storeCart'); if (s) storeState.cart = JSON.parse(s); } catch (e) { localStorage.removeItem('storeCart'); } }

// ===== XSS PROTECTION =====
function escapeHTML(str) {
  if (typeof str !== 'string') return String(str ?? '');
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

// ===== PRODUCTS =====
async function loadProducts() {
  const list = document.getElementById('productsList');
  if (list) list.innerHTML = '<p style="text-align:center;color:var(--muted-foreground);padding:3rem;">جاري تحميل المنتجات...</p>';
  
  try {
    const q = query(collection(db, "products"), orderBy("id", "desc"));
    const querySnapshot = await getDocs(q);
    storeState.products = querySnapshot.docs.map(doc => ({ _fsId: doc.id, ...doc.data() }));
    storeState.filteredProducts = [...storeState.products];
    renderProducts();
  } catch (e) { 
    console.error("Products load error:", e);
    if (list) list.innerHTML = '<p style="text-align:center;color:var(--muted-foreground);padding:3rem;">حدث خطأ في تحميل المنتجات</p>';
  }
}

function sortProducts(list) {
  const s = storeState.sortBy;
  if (s === 'price-asc')  return [...list].sort((a,b) => a.price - b.price);
  if (s === 'price-desc') return [...list].sort((a,b) => b.price - a.price);
  if (s === 'discount')   return [...list].sort((a,b) => ((b.originalPrice-b.price)/b.originalPrice) - ((a.originalPrice-a.price)/a.originalPrice));
  return list;
}

function renderProducts() {
  const list = document.getElementById('productsList');
  if (!list) return;
  const sorted = sortProducts(storeState.filteredProducts);
  if (sorted.length === 0) {
    list.innerHTML = '<p style="text-align:center;color:var(--muted-foreground);padding:3rem;">لا توجد منتجات مطابقة للبحث</p>';
    return;
  }
  list.innerHTML = sorted.map(p => `
    <div class="product-card reveal" onclick="viewProduct(${p.id})">
      <div class="product-image"><img src="${escapeHTML(p.image)}" alt="${escapeHTML(p.name)}" loading="lazy"/></div>
      <div class="product-info">
        <div class="product-category">${escapeHTML(getCategoryLabel(p.category))}</div>
        <h3 class="product-name">${escapeHTML(p.name)}</h3>
        <p class="product-description">${escapeHTML(p.description)}</p>
        <div class="product-price">
          <span class="current-price">${p.price} ج.م</span>
          ${p.originalPrice > p.price ? '<span class="original-price">' + p.originalPrice + ' ج.م</span><span class="discount-badge">-' + Math.round((1-p.price/p.originalPrice)*100) + '%</span>' : ''}
        </div>
        <div class="product-actions">
          <button onclick="event.stopPropagation();addToCart(${p.id})">أضف للسلة</button>
          <button onclick="event.stopPropagation();viewProduct(${p.id})">عرض التفاصيل</button>
        </div>
      </div>
    </div>`).join('');
  initializeIntersectionObserver();
}

window.filterProducts = function() {
  const q = document.getElementById('search-input').value.toLowerCase().trim();
  const cat = document.getElementById('category-filter').value;
  storeState.filteredProducts = storeState.products.filter(p =>
    (!q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)) &&
    (!cat || p.category === cat));
  renderProducts();
}

window.changeSortOrder = function(val) {
  storeState.sortBy = val;
  renderProducts();
}

window.viewProduct = function(id) {
  const p = storeState.products.find(x => x.id === id);
  if (!p) return;
  const discountHTML = p.originalPrice > p.price
    ? '<span class="original-price">' + p.originalPrice + ' ج.م</span><span class="discount-badge">-' + Math.round((1-p.price/p.originalPrice)*100) + '%</span>'
    : '';
  const detailEl = document.getElementById('productDetail');
  if (detailEl) {
    detailEl.innerHTML =
      '<div class="product-detail-image"><img src="' + escapeHTML(p.image) + '" alt="' + escapeHTML(p.name) + '"/></div>' +
      '<div class="product-detail-info">' +
        '<div class="product-detail-category">' + escapeHTML(getCategoryLabel(p.category)) + '</div>' +
        '<h2>' + escapeHTML(p.name) + '</h2>' +
        '<div class="product-detail-price"><span class="current-price">' + p.price + ' ج.م</span>' + discountHTML + '</div>' +
        '<div class="product-detail-description">' + escapeHTML(p.description) + '</div>' +
        '<div style="margin:1rem 0"><h4 style="margin-bottom:.5rem">المميزات:</h4>' +
          '<ul style="list-style:none;padding:0">' + (p.features || []).map(f => '<li style="padding:.3rem 0">✓ ' + escapeHTML(f) + '</li>').join('') + '</ul></div>' +
        '<div class="product-detail-actions">' +
          '<button class="btn-primary" onclick="addToCart(' + p.id + ');closeProductModal()">أضف للسلة</button>' +
          '<button class="btn-primary" style="background:rgba(79,195,195,.1);color:var(--accent)" onclick="closeProductModal()">إغلاق</button>' +
        '</div>' +
      '</div>';
  }
  document.getElementById('productModal').classList.add('open');
}
window.closeProductModal = function() { document.getElementById('productModal').classList.remove('open'); }

// ===== CART =====
window.addToCart = function(id) {
  if (!storeState.user) { showNotification('يجب تسجيل الدخول أولاً','error'); toggleAuthModal(); return; }
  const p = storeState.products.find(x => x.id === id);
  if (!p) return;
  const ex = storeState.cart.find(i => i.id === id);
  if (ex) { showNotification('هذا المنتج موجود في سلتك بالفعل','error'); return; }
  storeState.cart.push({ id: p.id, name: p.name, price: p.price, downloadLink: p.downloadLink });
  saveCartToStorage(); updateCartUI();
  showNotification('تم إضافة المنتج للسلة ✓','success');
}

window.removeFromCart = function(id) {
  storeState.cart = storeState.cart.filter(i => i.id !== id);
  saveCartToStorage(); updateCartUI();
}

function updateCartUI() {
  const countEl = document.getElementById('cart-count');
  const itemsEl = document.getElementById('cartItems');
  const totalEl = document.getElementById('cart-total');
  const totalItems = storeState.cart.length;
  const totalPrice = storeState.cart.reduce((s,i) => s + i.price, 0);
  if (countEl) countEl.textContent = totalItems;
  if (totalEl) totalEl.textContent = totalPrice.toLocaleString('ar-EG') + ' ج.م';
  if (itemsEl) {
    if (!storeState.cart.length) { itemsEl.innerHTML = '<p class="empty-message">السلة فارغة</p>'; return; }
    itemsEl.innerHTML = storeState.cart.map(i =>
      `<div class="cart-item">
        <div class="cart-item-info">
          <div class="cart-item-name">${escapeHTML(i.name)}</div>
          <div class="cart-item-price">${i.price} ج.م</div>
        </div>
        <button class="cart-item-remove" onclick="removeFromCart(${i.id})">✕</button>
      </div>`).join('');
  }
}

// ===== AUTHENTICATION =====
window.toggleAuthModal = function() { document.getElementById('authModal').classList.toggle('open'); }
window.switchAuthMode = function() {
  const isLogin = document.getElementById('auth-title').textContent === 'تسجيل الدخول';
  document.getElementById('auth-title').textContent = isLogin ? 'إنشاء حساب جديد' : 'تسجيل الدخول';
  document.getElementById('auth-submit-btn').textContent = isLogin ? 'إنشاء حساب' : 'دخول';
  document.getElementById('auth-switch-text').innerHTML = isLogin ? 'لديك حساب بالفعل؟ <a href="#" onclick="switchAuthMode()">سجل دخولك</a>' : 'ليس لديك حساب؟ <a href="#" onclick="switchAuthMode()">أنشئ حساباً</a>';
  const nameField = document.getElementById('auth-name-group');
  if (nameField) nameField.style.display = isLogin ? 'block' : 'none';
}

window.handleAuth = async function(e) {
  if (e) e.preventDefault();
  if (storeState.isProcessing) return;
  if (!checkLoginRateLimit()) return;
  
  const isLogin = document.getElementById('auth-title').textContent === 'تسجيل الدخول';
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-name')?.value.trim();
  
  if (!email || !password || (!isLogin && !name)) { showNotification('يرجى ملء جميع الحقول','error'); return; }
  
  storeState.isProcessing = true;
  const btn = document.getElementById('auth-submit-btn');
  const oldText = btn.textContent;
  btn.textContent = 'جاري المعالجة...';
  
  try {
    const hash = await hashPassword(password);
    const userRef = doc(db, "customers", email.replace(/\./g, '_'));
    const userSnap = await getDoc(userRef);
    
    if (isLogin) {
      if (userSnap.exists() && userSnap.data().password === hash) {
        storeState.user = { id: userSnap.data().id, name: userSnap.data().name, email: userSnap.data().email };
        saveUserToStorage(); updateAuthUI(); toggleAuthModal();
        showNotification('أهلاً بك مجدداً ' + storeState.user.name, 'success');
        resetLoginRateLimit();
      } else {
        showNotification('البريد أو كلمة المرور غير صحيحة', 'error');
      }
    } else {
      if (userSnap.exists()) {
        showNotification('هذا البريد مسجل بالفعل', 'error');
      } else {
        const newUser = { id: Date.now(), name, email, password: hash, registeredAt: new Date().toISOString() };
        await setDoc(userRef, newUser);
        storeState.user = { id: newUser.id, name: newUser.name, email: newUser.email };
        saveUserToStorage(); updateAuthUI(); toggleAuthModal();
        showNotification('تم إنشاء الحساب بنجاح 🎉', 'success');
      }
    }
  } catch (e) {
    showNotification('حدث خطأ في الاتصال', 'error');
  } finally {
    storeState.isProcessing = false;
    btn.textContent = oldText;
  }
}

window.logout = function() {
  if (confirm('هل تريد تسجيل الخروج؟')) {
    storeState.user = null;
    storeState.cart = [];
    localStorage.removeItem('storeUser');
    localStorage.removeItem('storeCart');
    updateAuthUI(); updateCartUI();
    showNotification('تم تسجيل الخروج بنجاح');
  }
}

function updateAuthUI() {
  const loginBtn = document.getElementById('login-nav-btn');
  const userBtn = document.getElementById('user-nav-btn');
  const userName = document.getElementById('user-name-display');
  if (storeState.user) {
    if (loginBtn) loginBtn.style.display = 'none';
    if (userBtn) userBtn.style.display = 'flex';
    if (userName) userName.textContent = storeState.user.name;
  } else {
    if (loginBtn) loginBtn.style.display = 'flex';
    if (userBtn) userBtn.style.display = 'none';
  }
}

// ===== UI HELPERS =====
function showNotification(msg, type = 'info') {
  const n = document.getElementById('notification');
  if (!n) return;
  n.textContent = msg;
  n.className = 'notification show ' + type;
  setTimeout(() => n.classList.remove('show'), 3000);
}

function initializeScrollBehavior() {
  const nav = document.querySelector('.nav-container');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  });
}

function initializeNavigation() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
}

function initializeIntersectionObserver() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('active');
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

function setupEventListeners() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.addEventListener('input', debounce(window.filterProducts, 300));
  
  const catFilter = document.getElementById('category-filter');
  if (catFilter) catFilter.addEventListener('change', window.filterProducts);
  
  const sortFilter = document.getElementById('sort-filter');
  if (sortFilter) sortFilter.addEventListener('change', (e) => window.changeSortOrder(e.target.value));
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => { clearTimeout(timeout); func(...args); };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

window.checkout = function() {
  if (!storeState.cart.length) { showNotification('السلة فارغة','error'); return; }
  showNotification('جاري تحويلك لإتمام الدفع...','success');
  // Here you would normally integrate a payment gateway
}
