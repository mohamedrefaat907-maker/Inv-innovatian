/* ============================================
   INV ADMIN PANEL - JAVASCRIPT (Firebase Edition)
   v6.4 — Cloud Production Fix
   ============================================ */

import { 
  db, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy, setDoc, getDoc 
} from './firebase-config.js';

// ===== CRYPTO HELPERS =====
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'inv_salt_2025');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ===== RATE LIMITER (Admin) =====
const _adminAttempts = { count: 0, lockedUntil: 0 };
function checkAdminRateLimit(errEl) {
  const now = Date.now();
  if (_adminAttempts.lockedUntil > now) {
    const secs = Math.ceil((_adminAttempts.lockedUntil - now) / 1000);
    if (errEl) errEl.textContent = 'كثرة المحاولات. انتظر ' + secs + ' ثانية';
    return false;
  }
  _adminAttempts.count++;
  if (_adminAttempts.count >= 5) {
    _adminAttempts.lockedUntil = now + 60000;
    _adminAttempts.count = 0;
    if (errEl) errEl.textContent = 'تم تجميد الدخول 60 ثانية';
    return false;
  }
  return true;
}

// ===== CATEGORY LABELS =====
const categoryLabels = { templates: 'قوالب', scripts: 'برامج نصية', courses: 'دورات تعليمية', tools: 'أدوات' };
function getCategoryLabel(cat) { return categoryLabels[cat] || cat; }

// ===== LOCAL SVG PLACEHOLDERS =====
const _svgB64 = (label) => {
  const s = '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="#1a1a1a"/><rect x="160" y="110" width="80" height="80" rx="8" fill="#4fc3c3" opacity="0.15"/><text x="200" y="158" font-family="Tajawal,sans-serif" font-size="13" fill="#4fc3c3" text-anchor="middle" dominant-baseline="middle">' + label + '</text></svg>';
  return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(s)));
};
const DEFAULT_PRODUCT_IMAGE = _svgB64('Product');

// ===== ADMIN STATE =====
const adminState = {
  isLoggedIn: false,
  currentTab: 'dashboard',
  products: [],
  orders: [],
  customers: [],
  settings: { storeName: 'INV Store', storeDescription: 'متجر المنتجات الرقمية المتقدمة', storeEmail: 'info@inv-store.com', storePhone: '+20 100 000 0000' },
  editingProductId: null
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async function () {
  await checkAdminAuth();
  if (adminState.isLoggedIn) {
    await loadAllData();
  }
  setupEventListeners();
});

// ===== XSS PROTECTION =====
function escapeHTML(str) {
  if (typeof str !== 'string') return String(str ?? '');
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

// ===== AUTHENTICATION =====
async function checkAdminAuth() {
  const adminAuth = localStorage.getItem('storeAdminAuth');
  if (adminAuth === 'authenticated') { 
    adminState.isLoggedIn = true; 
    return; 
  }

  try {
    const adminDoc = await getDoc(doc(db, "admin", "config"));
    if (!adminDoc.exists()) {
      // Auto-setup with admin133 if not exists
      const hash = await hashPassword('admin133');
      await setDoc(doc(db, "admin", "config"), { pwHash: hash });
      showAdminLoginModal();
    } else {
      showAdminLoginModal();
    }
  } catch (e) {
    console.error("Auth check error:", e);
    showAdminLoginModal();
  }
}

function showAdminLoginModal() {
  const existing = document.getElementById('adminLoginOverlay');
  if (existing) return;
  const overlay = document.createElement('div');
  overlay.id = 'adminLoginOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);display:flex;align-items:center;justify-content:center;z-index:9999;';
  overlay.innerHTML =
    '<div style="background:var(--card,#161616);border:1px solid var(--border,#2a2a2a);border-radius:12px;padding:2.5rem;width:90%;max-width:400px;text-align:center;">' +
      '<div style="font-size:2.5rem;margin-bottom:1rem">🔐</div>' +
      '<h2 style="margin-bottom:.5rem;color:var(--accent,#4fc3c3)">لوحة التحكم</h2>' +
      '<p style="color:#a0a0a0;margin-bottom:1.5rem;font-size:.9rem">أدخل كلمة مرور المدير للمتابعة</p>' +
      '<input type="password" id="adminPwInput" placeholder="كلمة المرور" autocomplete="current-password" ' +
        'style="width:100%;padding:.75rem 1rem;background:#1e1e1e;border:1px solid #2a2a2a;border-radius:8px;color:#f2f2f2;font-family:inherit;font-size:1rem;margin-bottom:1rem;direction:ltr;text-align:center;" />' +
      '<div id="adminLoginError" style="color:#ef4444;font-size:.85rem;margin-bottom:.75rem;min-height:1.2em"></div>' +
      '<button id="btnSubmitLogin" style="width:100%;padding:.75rem;background:var(--accent,#4fc3c3);color:#0d0d0d;border:none;border-radius:8px;font-size:1rem;font-weight:700;cursor:pointer;">دخول</button>' +
    '</div>';
  document.body.appendChild(overlay);
  document.getElementById('btnSubmitLogin').onclick = submitAdminLogin;
  document.getElementById('adminPwInput').onkeydown = (e) => { if(e.key==='Enter') submitAdminLogin(); };
  setTimeout(() => document.getElementById('adminPwInput')?.focus(), 100);
}

async function submitAdminLogin() {
  const input = document.getElementById('adminPwInput');
  const errEl = document.getElementById('adminLoginError');
  if (!input) return;
  if (!checkAdminRateLimit(errEl)) return;
  const pw = input.value;
  if (!pw) { if (errEl) errEl.textContent = 'أدخل كلمة المرور'; return; }
  
  try {
    const adminDoc = await getDoc(doc(db, "admin", "config"));
    const savedHash = adminDoc.exists() ? adminDoc.data().pwHash : null;
    
    // Fallback for first time if DB is empty
    const targetHash = savedHash || await hashPassword('admin133');
    
    const hash = await hashPassword(pw);
    if (hash === targetHash) {
      localStorage.setItem('storeAdminAuth', 'authenticated');
      adminState.isLoggedIn = true;
      _adminAttempts.count = 0; _adminAttempts.lockedUntil = 0;
      document.getElementById('adminLoginOverlay')?.remove();
      await loadAllData();
    } else {
      if (errEl) errEl.textContent = 'كلمة المرور غير صحيحة';
      input.value = ''; input.focus();
    }
  } catch (e) {
    if (errEl) errEl.textContent = 'خطأ في الاتصال بقاعدة البيانات';
  }
}

// ===== DATA LOADING =====
async function loadAllData() {
  if (!adminState.isLoggedIn) return;
  await Promise.all([
    loadProducts(),
    loadOrders(),
    loadCustomers(),
    loadSettings()
  ]);
  updateDashboard();
}

// ===== PRODUCTS =====
async function loadProducts() {
  try {
    const q = query(collection(db, "products"), orderBy("id", "desc"));
    const querySnapshot = await getDocs(q);
    adminState.products = querySnapshot.docs.map(doc => ({ _fsId: doc.id, ...doc.data() }));
    renderProductsTable();
  } catch (e) {
    console.error("Error loading products:", e);
  }
}

function renderProductsTable() {
  const tbody = document.getElementById('products-table-body');
  if (tbody) {
    tbody.innerHTML = adminState.products.length
      ? adminState.products.map(p =>
          '<tr>' +
            '<td>' + escapeHTML(p.name) + '</td>' +
            '<td>' + escapeHTML(getCategoryLabel(p.category)) + '</td>' +
            '<td>' + p.price + ' ج.م' + (p.originalPrice > p.price ? ' <s style="color:#666;font-size:.8rem">' + p.originalPrice + '</s>' : '') + '</td>' +
            '<td><a href="' + escapeHTML(p.downloadLink) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent);text-decoration:none;font-size:.8rem">رابط التحميل ↗</a></td>' +
            '<td><div class="table-actions">' +
              '<button onclick="editProduct(' + p.id + ')">تعديل</button>' +
              '<button class="delete" onclick="deleteProduct(' + p.id + ')">حذف</button>' +
            '</div></td>' +
          '</tr>'
        ).join('')
      : '<tr><td colspan="5" style="text-align:center;padding:2rem;color:#a0a0a0">لا توجد منتجات</td></tr>';
  }
  const mob = document.getElementById('products-mobile');
  if (mob) {
    mob.innerHTML = adminState.products.length
      ? adminState.products.map(p =>
          '<div class="data-card">' +
            '<div class="data-card-header">' +
              '<div class="data-card-title">' + escapeHTML(p.name) + '</div>' +
              '<div class="data-card-badge">' + escapeHTML(getCategoryLabel(p.category)) + '</div>' +
            '</div>' +
            '<div class="data-card-meta">' +
              '<span>💰 <strong>' + p.price + ' ج.م</strong>' + (p.originalPrice > p.price ? ' <s style="color:#666;font-size:.78rem">' + p.originalPrice + ' ج.م</s>' : '') + '</span>' +
              '<span style="font-size:.78rem;word-break:break-all">' + escapeHTML((p.description||'').substring(0,80)) + ((p.description||'').length > 80 ? '…' : '') + '</span>' +
            '</div>' +
            '<div class="data-card-actions">' +
              '<button class="btn-action btn-action-edit" onclick="editProduct(' + p.id + ')">✏️ تعديل</button>' +
              '<button class="btn-action btn-action-delete" onclick="deleteProduct(' + p.id + ')">🗑️ حذف</button>' +
            '</div>' +
          '</div>'
        ).join('')
      : '<p class="empty-state">لا توجد منتجات حالياً</p>';
  }
}

// Global functions attached to window
window.goToStore = () => window.location.href = 'index.html';
window.adminLogout = () => { if(confirm('هل تريد تسجيل الخروج؟')) { localStorage.removeItem('storeAdminAuth'); window.location.href = 'index.html'; } };

window.switchTab = function(tabName, clickedEl) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
  document.getElementById(tabName)?.classList.add('active');
  if (clickedEl) clickedEl.classList.add('active');
  adminState.currentTab = tabName;
  if (tabName === 'settings') fillSettingsFields();
};

window.openProductModal = function() {
  adminState.editingProductId = null;
  document.getElementById('product-modal-title').textContent = 'إضافة منتج جديد';
  ['product-name','product-category','product-description','product-price','product-original-price','product-download-link','product-image','product-features'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  document.getElementById('productModal').classList.add('open');
};

window.closeProductModal = () => document.getElementById('productModal').classList.remove('open');

window.editProduct = function(id) {
  const p = adminState.products.find(x => x.id === id);
  if (!p) return;
  adminState.editingProductId = id;
  document.getElementById('product-modal-title').textContent = 'تعديل المنتج';
  document.getElementById('product-name').value          = p.name;
  document.getElementById('product-category').value      = p.category;
  document.getElementById('product-description').value   = p.description;
  document.getElementById('product-price').value         = p.price;
  document.getElementById('product-original-price').value= p.originalPrice;
  document.getElementById('product-download-link').value = p.downloadLink;
  document.getElementById('product-image').value         = p.image || '';
  document.getElementById('product-features').value      = (p.features || []).join(', ');
  document.getElementById('productModal').classList.add('open');
};

window.saveProduct = async function() {
  const name          = document.getElementById('product-name').value.trim();
  const category      = document.getElementById('product-category').value;
  const description   = document.getElementById('product-description').value.trim();
  const price         = parseFloat(document.getElementById('product-price').value);
  const originalPrice = parseFloat(document.getElementById('product-original-price').value) || price;
  const downloadLink  = document.getElementById('product-download-link').value.trim();
  const image         = document.getElementById('product-image').value.trim() || DEFAULT_PRODUCT_IMAGE;
  const features      = document.getElementById('product-features').value.split(',').map(f => f.trim()).filter(Boolean);

  if (!name || !category || !description || !price || !downloadLink) { showNotification('يرجى ملء جميع الحقول المطلوبة','error'); return; }
  
  const productData = { name, category, description, price, originalPrice, downloadLink, image, features };

  try {
    if (adminState.editingProductId) {
      const p = adminState.products.find(x => x.id === adminState.editingProductId);
      if (p && p._fsId) {
        await updateDoc(doc(db, "products", p._fsId), productData);
        showNotification('تم تحديث المنتج بنجاح','success');
      }
    } else {
      productData.id = Date.now();
      await addDoc(collection(db, "products"), productData);
      showNotification('تم إضافة المنتج بنجاح','success');
    }
    await loadProducts(); window.closeProductModal(); updateDashboard();
  } catch (e) { showNotification('خطأ في حفظ المنتج','error'); }
};

window.deleteProduct = async function(id) {
  if (!confirm('هل تريد حذف هذا المنتج؟')) return;
  const p = adminState.products.find(x => x.id === id);
  if (p && p._fsId) {
    try {
      await deleteDoc(doc(db, "products", p._fsId));
      await loadProducts(); updateDashboard();
      showNotification('تم حذف المنتج','success');
    } catch (e) { showNotification('خطأ في حذف المنتج','error'); }
  }
};

// ===== ORDERS =====
async function loadOrders() {
  try {
    const q = query(collection(db, "orders"), orderBy("date", "desc"));
    const querySnapshot = await getDocs(q);
    adminState.orders = querySnapshot.docs.map(doc => ({ _fsId: doc.id, ...doc.data() }));
    renderOrdersTable();
  } catch (e) { console.error("Error loading orders:", e); }
}

function renderOrdersTable() {
  const tbody = document.getElementById('orders-table-body');
  if (tbody) {
    tbody.innerHTML = adminState.orders.length
      ? adminState.orders.map(o =>
          '<tr>' +
            '<td>#' + o.id + '</td>' +
            '<td>' + escapeHTML(o.userName) + '</td>' +
            '<td>' + escapeHTML(o.userEmail) + '</td>' +
            '<td>' + o.amount + ' ج.م</td>' +
            '<td>' + new Date(o.date).toLocaleDateString('ar-EG') + '</td>' +
            '<td><div class="table-actions">' +
              '<button onclick="viewOrder(' + o.id + ')">عرض</button>' +
              '<button class="delete" onclick="deleteOrder(' + o.id + ')">حذف</button>' +
            '</div></td>' +
          '</tr>'
        ).join('')
      : '<tr><td colspan="6" style="text-align:center;padding:2rem;color:#a0a0a0">لا توجد طلبات</td></tr>';
  }
  
  const mob = document.getElementById('orders-mobile');
  if (mob) {
    mob.innerHTML = adminState.orders.length
      ? adminState.orders.map(o =>
          '<div class="data-card">' +
            '<div class="data-card-header">' +
              '<div class="data-card-title">طلب #' + o.id + '</div>' +
              '<div class="data-card-badge">' + o.amount + ' ج.م</div>' +
            '</div>' +
            '<div class="data-card-meta">' +
              '<span>👤 <strong>' + escapeHTML(o.userName) + '</strong></span>' +
              '<span>📧 ' + escapeHTML(o.userEmail) + '</span>' +
              '<span>📅 ' + new Date(o.date).toLocaleDateString('ar-EG') + '</span>' +
            '</div>' +
            '<div class="data-card-actions">' +
              '<button class="btn-action btn-action-edit" onclick="viewOrder(' + o.id + ')">👁️ عرض</button>' +
              '<button class="btn-action btn-action-delete" onclick="deleteOrder(' + o.id + ')">🗑️ حذف</button>' +
            '</div>' +
          '</div>'
        ).join('')
      : '<p class="empty-state">لا توجد طلبات حالياً</p>';
  }
}

window.viewOrder = function(id) {
  const order = adminState.orders.find(o => o.id === id);
  if (!order) return;
  const itemsList = (order.items || []).map(i => '<li>' + escapeHTML(i.name) + ' × ' + (i.quantity||1) + ' — ' + (i.price*(i.quantity||1)) + ' ج.م</li>').join('');
  const dlList    = (order.downloadLinks || []).map(dl => '<li><a href="' + escapeHTML(dl.link) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent)">' + escapeHTML(dl.name) + '</a></li>').join('');
  
  const overlay = document.createElement('div');
  overlay.id = 'orderDetailOverlay'; overlay.className = 'modal open';
  overlay.innerHTML =
    '<div class="modal-content" style="max-width:480px">' +
      '<button class="modal-close" onclick="this.parentElement.parentElement.remove()">✕</button>' +
      '<h2>تفاصيل الطلب #' + order.id + '</h2>' +
      '<p><strong>المشتري:</strong> ' + escapeHTML(order.userName) + '</p>' +
      '<p><strong>المبلغ:</strong> ' + order.amount + ' ج.م</p>' +
      '<h4>المنتجات:</h4><ul>' + itemsList + '</ul>' +
      '<h4>روابط التحميل:</h4><ul>' + dlList + '</ul>' +
    '</div>';
  document.body.appendChild(overlay);
};

window.deleteOrder = async function(id) {
  if (!confirm('هل تريد حذف هذا الطلب؟')) return;
  const o = adminState.orders.find(x => x.id === id);
  if (o && o._fsId) {
    try {
      await deleteDoc(doc(db, "orders", o._fsId));
      await loadOrders(); updateDashboard();
      showNotification('تم حذف الطلب','success');
    } catch (e) { showNotification('خطأ في حذف الطلب','error'); }
  }
};

// ===== CUSTOMERS =====
async function loadCustomers() {
  try {
    const querySnapshot = await getDocs(collection(db, "customers"));
    adminState.customers = querySnapshot.docs.map(doc => ({ _fsId: doc.id, ...doc.data() }));
    renderCustomersTable();
  } catch (e) { console.error("Error loading customers:", e); }
}

function renderCustomersTable() {
  const tbody = document.getElementById('customers-table-body');
  if (tbody) {
    tbody.innerHTML = adminState.customers.length
      ? adminState.customers.map(c => {
          const cnt = adminState.orders.filter(o => o.userId === c.id).length;
          return '<tr>' +
            '<td>' + escapeHTML(c.name) + '</td>' +
            '<td>' + escapeHTML(c.email) + '</td>' +
            '<td>' + new Date(c.registeredAt).toLocaleDateString('ar-EG') + '</td>' +
            '<td>' + cnt + '</td>' +
            '<td><button class="delete" onclick="deleteCustomer(' + c.id + ')">حذف</button></td>' +
          '</tr>';
        }).join('')
      : '<tr><td colspan="5" style="text-align:center;padding:2rem;color:#a0a0a0">لا يوجد عملاء</td></tr>';
  }
  
  const mob = document.getElementById('customers-mobile');
  if (mob) {
    mob.innerHTML = adminState.customers.length
      ? adminState.customers.map(c => {
          const cnt = adminState.orders.filter(o => o.userId === c.id).length;
          return '<div class="data-card">' +
            '<div class="data-card-header">' +
              '<div class="data-card-title">' + escapeHTML(c.name) + '</div>' +
              '<div class="data-card-badge">' + cnt + ' طلب</div>' +
            '</div>' +
            '<div class="data-card-meta">' +
              '<span>📧 ' + escapeHTML(c.email) + '</span>' +
              '<span>📅 ' + new Date(c.registeredAt).toLocaleDateString('ar-EG') + '</span>' +
            '</div>' +
            '<div class="data-card-actions">' +
              '<button class="btn-action btn-action-delete" onclick="deleteCustomer(' + c.id + ')">🗑️ حذف</button>' +
            '</div>' +
          '</div>';
        }).join('')
      : '<p class="empty-state">لا يوجد عملاء حالياً</p>';
  }
}

window.deleteCustomer = async function(id) {
  if (!confirm('هل تريد حذف هذا العميل؟')) return;
  const c = adminState.customers.find(x => x.id === id);
  if (c && c._fsId) {
    try {
      await deleteDoc(doc(db, "customers", c._fsId));
      await loadCustomers(); updateDashboard();
      showNotification('تم حذف العميل','success');
    } catch (e) { showNotification('خطأ في حذف العميل','error'); }
  }
};

// ===== SETTINGS =====
async function loadSettings() {
  try {
    const docSnap = await getDoc(doc(db, "admin", "settings"));
    if (docSnap.exists()) {
      adminState.settings = { ...adminState.settings, ...docSnap.data() };
    }
  } catch (e) { console.error("Error loading settings:", e); }
}

function fillSettingsFields() {
  const s = adminState.settings;
  const fields = { storeName: s.storeName, storeDescription: s.storeDescription, storeEmail: s.storeEmail, storePhone: s.storePhone };
  Object.keys(fields).forEach(k => {
    const el = document.getElementById(k);
    if (el) el.value = fields[k];
  });
}

window.saveSettings = async function() {
  const settings = {
    storeName: document.getElementById('storeName')?.value || '',
    storeDescription: document.getElementById('storeDescription')?.value || '',
    storeEmail: document.getElementById('storeEmail')?.value || '',
    storePhone: document.getElementById('storePhone')?.value || ''
  };
  
  const newPw = document.getElementById('admin-new-password')?.value.trim();
  
  if (!settings.storeName || !settings.storeEmail) { showNotification('يرجى ملء الحقول المطلوبة','error'); return; }
  
  try {
    await setDoc(doc(db, "admin", "settings"), settings);
    
    if (newPw) {
      if (newPw.length < 6) { showNotification('كلمة المرور الجديدة قصيرة جداً','error'); return; }
      const hash = await hashPassword(newPw);
      await updateDoc(doc(db, "admin", "config"), { pwHash: hash });
      showNotification('تم تحديث الإعدادات وكلمة المرور','success');
    } else {
      showNotification('تم حفظ الإعدادات بنجاح','success');
    }
    
    adminState.settings = settings;
  } catch (e) { showNotification('خطأ في حفظ الإعدادات','error'); }
};

// ===== DASHBOARD =====
function updateDashboard() {
  const totalRevenue = adminState.orders.reduce((sum, o) => sum + (o.amount || 0), 0);
  document.getElementById('total-products').textContent = adminState.products.length;
  document.getElementById('total-customers').textContent = adminState.customers.length;
  document.getElementById('total-orders').textContent = adminState.orders.length;
  document.getElementById('total-revenue').textContent = totalRevenue + ' ج.م';
  
  const recentOrders = adminState.orders.slice(0, 5);
  const recentHtml = recentOrders.length
    ? recentOrders.map(o => '<div style="padding:1rem;border-bottom:1px solid #2a2a2a;display:flex;justify-content:space-between;align-items:center;"><div><strong>#' + o.id + '</strong> — ' + escapeHTML(o.userName) + '</div><span style="color:var(--accent)">' + o.amount + ' ج.م</span></div>').join('')
    : '<p style="padding:1rem;color:#a0a0a0">لا توجد طلبات</p>';
  const recentEl = document.getElementById('recent-orders');
  if (recentEl) recentEl.innerHTML = recentHtml;
}

// ===== NOTIFICATIONS =====
function showNotification(msg, type = 'info') {
  const notif = document.createElement('div');
  notif.style.cssText = 'position:fixed;top:1rem;right:1rem;background:' + (type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6') + ';color:white;padding:1rem 1.5rem;border-radius:8px;z-index:10000;animation:slideIn .3s ease;';
  notif.textContent = msg;
  document.body.appendChild(notif);
  setTimeout(() => notif.remove(), 3000);
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
  const productModal = document.getElementById('productModal');
  if (productModal) {
    productModal.onclick = (e) => { if (e.target === productModal) window.closeProductModal(); };
  }
}

// Add CSS animation
const style = document.createElement('style');
style.textContent = '@keyframes slideIn { from { transform: translateX(400px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }';
document.head.appendChild(style);
